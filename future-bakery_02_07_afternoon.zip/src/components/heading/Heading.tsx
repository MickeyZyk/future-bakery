import * as React from 'react';

import { Container } from 'components/container/Container';
import { Row } from 'components/row/Row';

import { Power2 } from "gsap/TweenMax";
import { Tween} from 'react-gsap'
import { TransitionState } from "gatsby-plugin-transition-link";

import s from './Heading.scss';

interface IIntroProps {
  children: React.ReactNode;
}

export const Heading = ({ children, delay, className }: IIntroProps) => {
  return (

    <TransitionState>
      {({ transitionStatus }) => {
        return (

	        <Tween delay={delay} duration={1} from={ ['entering'].includes(transitionStatus) ? false : { opacity: 0, delay: .5, yPercent: -200, ease: Power2.easeOut } } to={ ['exiting'].includes(transitionStatus) ? { opacity: 0, delay: .5, yPercent: -200, ease: Power2.easeIn} : false } >
	    	  	<h2 className={className}>{children}</h2>
	    	  </Tween>

        )
      }}
    </TransitionState>

  );
};
